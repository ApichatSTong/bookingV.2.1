<?php
/**
 * @filesource modules/index/views/register.php
 *
 * @copyright 2016 Goragod.com
 * @license http://www.kotchasan.com/license/
 *
 * @see http://www.kotchasan.com/
 */

namespace Index\Register;

use Kotchasan\Html;
use Kotchasan\Http\Request;

/**
 * module=register
 *
 * @author Goragod Wiriya <admin@goragod.com>
 *
 * @since 1.0
 */
class View extends \Gcms\View
{
    /**
     * ลงทะเบียนสมาชิกใหม่
     *
     * @param Request $request
     *
     * @return string
     */
    public function render(Request $request)
    {
        $form = Html::create('form', array(
            'id' => 'setup_frm',
            'class' => 'setup_frm',
            'autocomplete' => 'off',
            'action' => 'index.php/index/model/register/submit',
            'onsubmit' => 'doFormSubmit',
            'ajax' => true,
            'token' => true
        ));
        $fieldset = $form->add('fieldset', array(
            'title' => '{LNG_Details of} {LNG_User}'
        ));
        $groups = $fieldset->add('groups');
        // username
        $groups->add('text', array(
            'id' => 'register_username',
            'itemClass' => 'width50',
            'labelClass' => 'g-input icon-email',
            'label' => '{LNG_Email}/{LNG_Username}',
            'comment' => '{LNG_Email address used for login or request a new password}',
            'maxlength' => 50,
            'validator' => array('keyup,change', 'checkUsername', 'index.php/index/model/checker/username')
        ));
        // name
        $groups->add('text', array(
            'id' => 'register_name',
            'labelClass' => 'g-input icon-customer',
            'itemClass' => 'width50',
            'label' => '{LNG_Name}',
            'comment' => '{LNG_Please fill in} {LNG_Name}',
            'maxlength' => 100
        ));
        $groups = $fieldset->add('groups');
        // password
        $groups->add('password', array(
            'id' => 'register_password',
            'itemClass' => 'width50',
            'labelClass' => 'g-input icon-password',
            'label' => '{LNG_Password}',
            'comment' => '{LNG_Passwords must be at least four characters}',
            'maxlength' => 20,
            'showpassword' => true,
            'validator' => array('keyup,change', 'checkPassword')
        ));
        // repassword
        $groups->add('password', array(
            'id' => 'register_repassword',
            'itemClass' => 'width50',
            'labelClass' => 'g-input icon-password',
            'label' => '{LNG_Repassword}',
            'comment' => '{LNG_Enter your password again}',
            'maxlength' => 20,
            'showpassword' => true,
            'validator' => array('keyup,change', 'checkPassword')
        ));

        // department
        $fieldset->add('select', array(
            'id' => 'register_province',
            'labelClass' => 'g-input icon-menus',
            'itemClass' => 'item',
            'label' => '{LNG_Section}',
            'options' => array(
                'TY1A : Sales' => 'TY1A : Sales',
                'TY2A : Rental' => 'TY2A : Rental',
                'TY2Z : Parts Support' => 'TY2Z : Parts Support',
                'TY3A : Service' => 'TY3A : Service',
                'TY4A : Parts' => 'TY4A : Parts',
                'TY5A : Workshop & PDI' => 'TY5A : Workshop & PDI',
                'TY6A : Warehouse ' => 'TY6A : Warehouse',
                'TY6B : Transportation' => 'TY6B : Transportation',
                'TY7A : Marketing & Advertising' => 'TY7A : Marketing & Advertising',
                'TY8A : Second Hand' => 'TY8A : Second Hand',
                'TY9A : Battery BIZ Creation' => 'TY9A : Battery BIZ Creation',
                'TYS1 : Credit Control' => 'TYS1 : Credit Control',
                'TYT1 : Cooperative Planning' => 'TYT1 : Cooperative Planning',
                'TYV0 : Legal' => 'TYV0 : Legal',
                'TYW2 : ISO' => 'TYW2 : ISO',
                'TYW3 : Safety' => 'TYW3 : Safety',
                'TYX2 : Finance' => 'TYX2 : Finance',
                'TYX3 : IT' => 'TYX3 : IT',
                'TYY1 : Personnel' => 'TYY1 : Personnel',
                'TYY2 : Training' => 'TYY2 : Training',
                'TYY4 : HRD' => 'TYY4 : HRD',
                'TYZ1 : General Affair' => 'TYZ1 : General Affair',
                'TYZ2 : Purchasing' => 'TYZ2 : Purchasing'
              ),
           // 'value' => $user['province'],
        ));

        // status
        $fieldset->add('select', array(
            'id' => 'register_status',
            'itemClass' => 'item',
            'label' => '{LNG_Member status}',
            'labelClass' => 'g-input icon-star0',
            'options' => self::$cfg->member_status,
            'value' => 0
        ));
        // permission
        $fieldset->add('checkboxgroups', array(
            'id' => 'register_permission',
            'itemClass' => 'item',
            'label' => '{LNG_Permission}',
            'labelClass' => 'g-input icon-list',
            'options' => \Gcms\Controller::getPermissions(),
            'value' => \Gcms\Controller::initModule(array(), 'newRegister')
        ));
        $fieldset = $form->add('fieldset', array(
            'class' => 'submit'
        ));
        // submit
        $fieldset->add('submit', array(
            'class' => 'button save large icon-register',
            'value' => '{LNG_Register}'
        ));
        $fieldset->add('hidden', array(
            'id' => 'register_id',
            'value' => 0
        ));
        // คืนค่า HTML
        return $form->render();
    }
}
