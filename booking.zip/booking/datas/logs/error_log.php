<?php exit() ?>
[2022-04-18 16:36:54] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-18 16:38:07] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-18 16:46:38] ERROR: <br>Exception : <em>syntax error, unexpected token "}", expecting ";"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-18 16:46:50] ERROR: <br>Exception : <em>syntax error, unexpected token "}", expecting ";"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-19 13:30:53] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 13:31:06] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 13:31:08] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 13:31:27] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 13:31:29] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 13:32:14] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 13:33:00] ERROR: <br>Exception : <em>syntax error, unexpected token "if", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 14:25:44] ERROR: <br>Exception : <em>Class "Index\Register\Language" not found</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 14:27:11] ERROR: <br>Exception : <em>Class "Index\Register\Language" not found</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 14:27:43] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>97</b> 
[2022-04-19 14:27:43] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>97</b> 
[2022-04-19 14:27:43] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>97</b> 
[2022-04-19 14:27:43] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>97</b> 
[2022-04-19 15:47:16] ERROR: <br>Exception : <em>Class "Index\Register\Language" not found</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 15:47:34] ERROR: <br>Exception : <em>Class "Index\Register\language" not found</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 16:09:26] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:09:26] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:09:26] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:09:26] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>153</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>153</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>153</b> 
[2022-04-19 16:17:03] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>153</b> 
[2022-04-19 17:17:15] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 17:17:26] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 17:17:29] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 17:17:36] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 17:17:38] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-19 17:18:03] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:18:03] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:18:03] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:18:03] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:36:58] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:36:58] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:36:58] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:36:58] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:39:42] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:39:42] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:39:42] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:39:42] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:18] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:18] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:18] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:18] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:24] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:24] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:24] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:24] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:38] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:38] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:38] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:40:38] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>135</b> 
[2022-04-19 17:41:24] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>136</b> 
[2022-04-19 17:41:24] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>136</b> 
[2022-04-19 17:41:39] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:41:39] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:42:00] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:42:00] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:42:27] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:42:27] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:20] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:32] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:33] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:42] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:43] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-19 17:44:52] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>137</b> 
[2022-04-20 18:37:37] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'R.member_id' in 'on clause'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-20 18:37:51] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:38:43] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:38:50] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'R.member_id' in 'on clause'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-20 18:39:52] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'R.member_id' in 'on clause'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-20 18:40:39] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:40:59] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:41:09] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'R.member_id' in 'on clause'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-20 18:41:25] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'R.member_id' in 'on clause'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-20 18:43:35] ERROR: <br>Exception : <em>syntax error, unexpected token ","</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:43:48] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'R.member_id' in 'on clause'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-20 18:45:41] ERROR: <br>Exception : <em>syntax error, unexpected token ","</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:45:48] ERROR: <br>Exception : <em>syntax error, unexpected token ","</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:46:28] ERROR: <br>Exception : <em>syntax error, unexpected token "."</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:46:34] ERROR: <br>Exception : <em>syntax error, unexpected token "*"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:46:53] ERROR: <br>Exception : <em>syntax error, unexpected token "*"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Router.php</b> on line <b>72</b> 
[2022-04-20 18:51:08] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:51:22] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:51:24] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:51:56] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:52:32] ERROR: <br>Exception : <em>syntax error, unexpected token "foreach", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:52:34] ERROR: <br>Exception : <em>syntax error, unexpected token "foreach", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:53:58] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:54:15] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:54:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>139</b> 
[2022-04-20 18:54:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>139</b> 
[2022-04-20 18:55:58] ERROR: <br>Exception : <em>syntax error, unexpected token "foreach", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 18:56:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 18:56:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 18:56:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 18:56:18] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 18:56:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 18:56:54] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:26] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:26] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:26] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:26] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:34] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:34] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:07:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:10:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:10:06] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:10:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$register_province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:10:37] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$register_province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:12:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:12:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$register_province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:12:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:12:49] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$register_province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:13:10] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:13:10] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:13:11] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:13:11] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:14:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:14:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:14:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:14:47] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:16:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:16:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:16:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:16:41] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:21:30] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:21:30] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:21:31] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:21:31] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:25:46] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:25:46] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:25:46] ERROR: <br>PHP warning : <em>Undefined variable $user</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:25:46] ERROR: <br>PHP warning : <em>Trying to access array offset on value of type null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\views\register.php</b> on line <b>122</b> 
[2022-04-20 19:30:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:30:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:30:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>140</b> 
[2022-04-20 19:30:40] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>149</b> 
[2022-04-20 19:32:04] ERROR: <br>PHP warning : <em>Undefined variable $province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\booking.php</b> on line <b>50</b> 
[2022-04-20 19:32:04] ERROR: <br>PHP warning : <em>Undefined variable $province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\booking.php</b> on line <b>50</b> 
[2022-04-20 19:33:23] ERROR: <br>Exception : <em>syntax error, unexpected variable "$fieldset", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 19:33:33] ERROR: <br>Exception : <em>syntax error, unexpected token "foreach", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 19:34:18] ERROR: <br>Exception : <em>syntax error, unexpected token "foreach", expecting "function" or "const"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 19:34:47] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 19:34:56] ERROR: <br>Exception : <em>syntax error, unexpected token "/"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-20 19:36:50] ERROR: <br>PHP warning : <em>Undefined variable $category</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\booking.php</b> on line <b>162</b> 
[2022-04-20 19:36:50] ERROR: <br>Exception : <em>Call to a member function toSelect() on null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-21 13:07:11] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:07:15] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:07:19] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:07:45] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:08:00] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:08:15] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:08:24] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:09:09] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:09:30] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:11:30] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:30] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:30] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:30] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:44] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:44] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:44] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:11:44] ERROR: <br>PHP warning : <em>Undefined array key "topic"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>200</b> 
[2022-04-21 13:13:29] ERROR: <br>Exception : <em>syntax error, unexpected token "public"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 13:13:57] ERROR: <br>PHP warning : <em>Undefined variable $select</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>65</b> 
[2022-04-21 13:13:57] ERROR: <br>Exception : <em>array_merge(): Argument #1 must be of type array, null given</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>95</b> 
[2022-04-21 13:15:38] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'M1.value' in 'field list'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>221</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>193</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "contact"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "begin"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP Error : <em>preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>221</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>193</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "contact"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "begin"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP Error : <em>preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:52] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>221</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>193</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "contact"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "begin"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP Error : <em>preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>221</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "today"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>193</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "phone"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "contact"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>196</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "begin"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP Error : <em>preg_match(): Passing null to parameter #2 ($subject) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Gcms\View.php</b> on line <b>113</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "create_date"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>199</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key "status"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 13:19:53] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>207</b> 
[2022-04-21 14:06:20] ERROR: <br>Exception : <em>syntax error, unexpected single-quoted string "province", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 14:08:33] ERROR: <br>Exception : <em>syntax error, unexpected identifier "Sql", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 14:13:18] ERROR: <br>Exception : <em>syntax error, unexpected variable "$item"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 14:16:43] ERROR: <br>Exception : <em>syntax error, unexpected identifier "Sql", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 14:17:47] ERROR: <br>Exception : <em>syntax error, unexpected identifier "Sql", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 14:21:55] ERROR: <br>Exception : <em>syntax error, unexpected token "array", expecting ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 14:33:46] ERROR: <br>Exception : <em>Unsupported operand types: array + int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:06:30] ERROR: <br>Exception : <em>syntax error, unexpected token "->"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\index.php</b> on line <b>57</b> 
[2022-04-21 15:15:19] ERROR: <br>PHP warning : <em>Undefined variable $n</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>54</b> 
[2022-04-21 15:15:19] ERROR: <br>PHP warning : <em>Undefined variable $n</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>55</b> 
[2022-04-21 15:15:19] ERROR: <br>PHP warning : <em>Undefined variable $query</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>60</b> 
[2022-04-21 15:15:19] ERROR: <br>Exception : <em>Call to a member function join() on null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 15:15:34] ERROR: <br>PHP warning : <em>Undefined variable $n</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>54</b> 
[2022-04-21 15:15:34] ERROR: <br>PHP warning : <em>Undefined variable $n</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>55</b> 
[2022-04-21 15:15:34] ERROR: <br>PHP warning : <em>Undefined variable $query</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>60</b> 
[2022-04-21 15:15:34] ERROR: <br>Exception : <em>Call to a member function join() on null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 15:15:41] ERROR: <br>PHP warning : <em>Undefined variable $n</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>54</b> 
[2022-04-21 15:15:41] ERROR: <br>PHP warning : <em>Undefined variable $n</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>55</b> 
[2022-04-21 15:15:41] ERROR: <br>PHP warning : <em>Undefined variable $query</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>60</b> 
[2022-04-21 15:15:41] ERROR: <br>Exception : <em>Call to a member function join() on null</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>78</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:17] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>88</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>89</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>90</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined array key ""</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>88</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>89</b> 
[2022-04-21 15:18:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>90</b> 
[2022-04-21 15:20:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:20:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:20:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:20:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:21:20] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, string given</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>70</b> 
[2022-04-21 15:21:20] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, string given</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>70</b> 
[2022-04-21 15:21:52] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, string given</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>70</b> 
[2022-04-21 15:21:52] ERROR: <br>PHP warning : <em>foreach() argument must be of type array|object, string given</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>70</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:29:41] ERROR: <br>Exception : <em>syntax error, unexpected variable "$filters"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:30:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:31:04] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:31:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:31:50] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:48:29] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:48:29] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:48:29] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:48:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:48:30] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:48:30] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:48:30] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:48:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:52:55] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:52:55] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:52:55] ERROR: <br>Exception : <em>Unsupported operand types: array * int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:53:15] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:53:15] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:53:15] ERROR: <br>Exception : <em>Unsupported operand types: array * int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:53:47] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:53:47] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:53:47] ERROR: <br>Exception : <em>Unsupported operand types: array * int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:53:49] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:53:49] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:53:49] ERROR: <br>Exception : <em>Unsupported operand types: array * int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:53:52] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:53:52] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:53:52] ERROR: <br>Exception : <em>Unsupported operand types: array * int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:53:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:53:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:53:59] ERROR: <br>Exception : <em>Unsupported operand types: array * int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:54:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:54:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:55:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:55:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 15:55:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:56:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:14] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:14] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:57:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:03] ERROR: <br>Exception : <em>syntax error, unexpected token ";"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:58:08] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:08] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:08] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:08] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:40] ERROR: <br>Exception : <em>syntax error, unexpected token ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 15:58:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 15:58:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:06:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:08:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:09:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:19:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:20:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:25:01] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:25:01] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 16:25:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:25:01] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:25:01] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 16:25:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:25:16] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:25:16] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 16:25:16] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:25:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:25:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:25:17] ERROR: <br>PHP warning : <em>Undefined variable $label</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>84</b> 
[2022-04-21 16:25:17] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:25:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:27:01] ERROR: <br>Exception : <em>syntax error, unexpected token ")"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\report.php</b> on line <b>52</b> 
[2022-04-21 16:27:49] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:27:49] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:27:49] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>83</b> 
[2022-04-21 16:27:49] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:27:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:28:08] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:28:08] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:28:08] ERROR: <br>PHP warning : <em>Undefined variable $key</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>85</b> 
[2022-04-21 16:28:08] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:28:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:28:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:28:37] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:28:37] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:30:06] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:30:06] ERROR: <br>PHP Error : <em>setcookie(): Passing null to parameter #2 ($value) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>188</b> 
[2022-04-21 16:30:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:30:07] ERROR: <br>PHP Error : <em>setcookie(): Passing null to parameter #2 ($value) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>188</b> 
[2022-04-21 16:36:46] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:36:46] ERROR: <br>PHP Error : <em>setcookie(): Passing null to parameter #2 ($value) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>188</b> 
[2022-04-21 16:36:46] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-21 16:36:46] ERROR: <br>PHP Error : <em>setcookie(): Passing null to parameter #2 ($value) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>188</b> 
[2022-04-21 16:45:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:45:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:45:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:45:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:05] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-21 16:46:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 08:33:47] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 08:33:47] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 08:33:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 08:33:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 09:21:13] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\detail.php</b> on line <b>70</b> 
[2022-04-22 09:26:14] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\detail.php</b> on line <b>70</b> 
[2022-04-22 09:27:26] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\detail.php</b> on line <b>70</b> 
[2022-04-22 14:35:56] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\detail.php</b> on line <b>70</b> 
[2022-04-22 14:38:28] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\detail.php</b> on line <b>70</b> 
[2022-04-22 14:38:31] ERROR: <br>PHP warning : <em>Undefined property: stdClass::$province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\detail.php</b> on line <b>70</b> 
[2022-04-22 14:41:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:41:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:41:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:41:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:52:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:52:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:52:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 14:52:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 15:17:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 15:17:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 15:17:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-22 15:17:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:07:55] ERROR: <br>PHP Error : <em>substr(): Passing null to parameter #1 ($string) of type string is deprecated</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\calendar.php</b> on line <b>81</b> 
[2022-04-25 11:13:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:10] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:10] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:10] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:10] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:41] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:13:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:15] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:14:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:16:06] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:06] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:07] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:09] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:09] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:09] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:09] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>77</b> 
[2022-04-25 11:16:21] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:16:21] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:16:21] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:16:21] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:17:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:46] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:46] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:49] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:23:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:11] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:14] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:14] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:17] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:45] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:46] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:46] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:56] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:56] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:24:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:02] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:02] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:03] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:03] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:04] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:04] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:04] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:04] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:25:29] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:26:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:50] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:50] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:50] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 11:27:50] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:20] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:20] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:20] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:20] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:48] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 12:38:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:12] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:40:16] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:55] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:50:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:51:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:51:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:51:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:51:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:38] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:44] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:51] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:52] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:54:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:54:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:55:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:55:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:55:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:55:53] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'U.provice' in 'field list'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 13:55:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:55:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:55:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:55:54] ERROR: <br>Exception : <em>SQLSTATE[42S22]: Column not found: 1054 Unknown column 'U.provice' in 'field list'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 13:56:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:18] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:22] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:24] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:56:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:56:26] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:57:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:57:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:57:53] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:57:53] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 13:57:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:57:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:57:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:57:54] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 13:58:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:58:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:58:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:58:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>76</b> 
[2022-04-25 13:58:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:13] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:23] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:25] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:27] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:30] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:32] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:32] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:34] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:34] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:35] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:36] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:37] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:37] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 13:58:39] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:02:28] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:02:28] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:02:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:02:43] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:02:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:02:59] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:03:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:03:01] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:03:31] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:03:31] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 14:04:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:04:54] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:04:57] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:04:58] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:05:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:05:00] ERROR: <br>PHP warning : <em>Undefined array key "province"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\views\report.php</b> on line <b>86</b> 
[2022-04-25 14:34:11] ERROR: <br>Exception : <em>SQLSTATE[42S21]: Column already exists: 1060 Duplicate column name 'province'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 14:36:01] ERROR: <br>PHP notice : <em>Object of class Kotchasan\InputItem could not be converted to int</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\report.php</b> on line <b>46</b> 
[2022-04-25 14:36:01] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:36:15] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:36:24] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:36:31] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:36:31] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:37:34] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:37:47] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:38:47] ERROR: <br>Exception : <em>syntax error, unexpected token "->"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\controllers\report.php</b> on line <b>79</b> 
[2022-04-25 14:40:25] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:40:54] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:40:54] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 14:41:29] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 15:04:58] ERROR: <br>Exception : <em>Invalid arguments in quoteValue</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Sql.php</b> on line <b>809</b> 
[2022-04-25 15:14:28] ERROR: <br>Exception : <em>syntax error, unexpected token "foreach"</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\index\controllers\main.php</b> on line <b>110</b> 
[2022-04-25 17:02:35] ERROR: <br>PHP warning : <em>Undefined variable $province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\email.php</b> on line <b>79</b> 
[2022-04-25 17:04:28] ERROR: <br>PHP warning : <em>Undefined variable $province</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\modules\booking\models\email.php</b> on line <b>79</b> 
[2022-04-25 17:11:32] ERROR: <br>Exception : <em>SQLSTATE[42S02]: Base table or view not found: 1146 Table 'booking.booking_reservation' doesn't exist</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 17:11:47] ERROR: <br>Exception : <em>SQLSTATE[42S02]: Base table or view not found: 1146 Table 'booking.booking_reservation' doesn't exist</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 17:12:01] ERROR: <br>Exception : <em>SQLSTATE[42S02]: Base table or view not found: 1146 Table 'booking.booking_reservation' doesn't exist</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Driver.php</b> on line <b>262</b> 
[2022-04-25 17:12:28] ERROR: <br>Exception : <em>SQLSTATE[HY000] [1049] Unknown database 'booking'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Db.php</b> on line <b>38</b> 
[2022-04-25 17:13:48] ERROR: <br>Exception : <em>SQLSTATE[HY000] [1049] Unknown database 'booking'</em> in <b>D:\xampp\htdocs\booking-room-TTFL-master\Kotchasan\Database\Db.php</b> on line <b>38</b> 